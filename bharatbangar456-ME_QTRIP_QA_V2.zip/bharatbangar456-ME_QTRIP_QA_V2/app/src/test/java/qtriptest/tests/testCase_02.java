package qtriptest.tests;
import qtriptest.DP;
import qtriptest.DriverSingleton;
import qtriptest.pages.AdventurePage;
import qtriptest.pages.HomePage;
import qtriptest.pages.LoginPage;
import java.net.MalformedURLException;
import java.net.URL;
import org.apache.logging.log4j.core.util.Assert;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;


public class testCase_02 {
    static RemoteWebDriver driver;
    HomePage homePage;
    
    @BeforeSuite(alwaysRun = true, enabled = true )
    // public static void createDriver() throws MalformedURLException {
    //     logStatus("driver", "Initializing driver", "Started");
    //     final DesiredCapabilities capabilities = new DesiredCapabilities();
    //     capabilities.setBrowserName(BrowserType.CHROME);
    //     driver = new RemoteWebDriver(new URL("http://localhost:8082/wd/hub"), capabilities);
    //     logStatus("driver", "Initializing driver", "Success");
    //}

    public static void createDriver() throws MalformedURLException {
        logStatus("driver", "Initializing driver", "Started");
        driver=DriverSingleton.getDriverInstance("chrome");
       // driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        logStatus("driver", "Initializing driver", "Success");
    }

    private static void logStatus(String string, String string2, String string3) {}

    @Test(dataProvider ="userOnboard",dataProviderClass = DP.class, enabled=true,description = "verify Search and Filter flow" , priority = 2, groups={"Search and Filter flow"} )
    public void TestCase02(String CityName,String Category_Filter,String DurationFilter,
    String ExpectedFilteredResults, String ExpectedUnFilteredResults) throws InterruptedException {
        driver.manage().window().maximize();
        
        HomePage homePage = new HomePage(driver);
        //driver.get("https://qtripdynamic-qa-frontend.vercel.app/");
        Thread.sleep(3000);
        SoftAssert s_assert = new SoftAssert();
  
       homePage.navigateToHomePage();
       Thread.sleep(3000);
       homePage.searchCity(CityName);
       Thread.sleep(3000);
       //s_assert.assertTrue(homepge.isCityNotFound()||homepge.isCityFound());
       homePage.selectCity();
       Thread.sleep(3000);
       AdventurePage adventure= new AdventurePage(driver);
       
       adventure.setDurationFilter(DurationFilter);
       Thread.sleep(2000);
       adventure.setCatrgoryFilter(Category_Filter);
       Thread.sleep(2000);
       adventure.verifyAdventureContents(ExpectedFilteredResults);
       Thread.sleep(2000);
       adventure.verifyAdventureContents(ExpectedUnFilteredResults);
       Thread.sleep(3000);
      // HomePage homePage1 = new HomePage(driver);
      // homePage.navigateToHomePage();
       
    
     } 
    //  @AfterTest(enabled = true)
    //  public void quitDriver() throws MalformedURLException {
    //      driver.close();
    //     //  driver.quit();
    //      logStatus("driver", "Quitting driver", "Success");
    //  }
}
