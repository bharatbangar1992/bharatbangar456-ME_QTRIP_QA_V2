package qtriptest.tests;

import qtriptest.DP;
import qtriptest.DriverSingleton;
import qtriptest.pages.AdventureDetailsPage;
import qtriptest.pages.AdventurePage;
import qtriptest.pages.HistoryPage;
import qtriptest.pages.HomePage;
import qtriptest.pages.LoginPage;
import qtriptest.pages.Registration;
import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class testCase_03 {
  static RemoteWebDriver driver;
  public String lastUsername;
  HomePage homePage;

  // Method to help us log our Unit Tests
  public static void logStatus(String type, String message, String status) {
    System.out.println(String.format("%s |  %s  |  %s | %s",
        String.valueOf(java.time.LocalDateTime.now()), type, message, status));
  }

  // Iinitialize webdriver for our Unit Tests

  @BeforeSuite(alwaysRun = true, enabled = true )
    // public static void createDriver() throws MalformedURLException {
    //     logStatus("driver", "Initializing driver", "Started");
    //     final DesiredCapabilities capabilities = new DesiredCapabilities();
    //     capabilities.setBrowserName(BrowserType.CHROME);
    //     driver = new RemoteWebDriver(new URL("http://localhost:8082/wd/hub"), capabilities);
    //     logStatus("driver", "Initializing driver", "Success");
    // }

    public static void createDriver() throws MalformedURLException {
      logStatus("driver", "Initializing driver", "Started");
      driver=DriverSingleton.getDriverInstance("chrome");
     // driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
      logStatus("driver", "Initializing driver", "Success");
  }

  @Test(dataProvider = "userOnboard", dataProviderClass = DP.class,  enabled=true,
  description = "verify booking and cancellation flow" , priority = 3, groups={"Booking and Cancellation Flow"})
  public void TestCase03(String NewUserName, String Password, String SearchCity,
      String AdventureName, String GuestName, String Date, String count)
      throws InterruptedException {

    HomePage homepage = new HomePage(driver);
    Thread.sleep(3000);
    homepage.navigateToHomePage();

   
    Registration registration = new Registration(driver);
    Thread.sleep(3000);
    homepage.navigateToRegisterPage();
    Thread.sleep(2000);
    registration.registerNewUser(NewUserName, Password);
    Thread.sleep(2000);

    AdventurePage adventure = new AdventurePage(driver);
    HistoryPage history = new HistoryPage(driver);

    LoginPage loginPage = new LoginPage(driver);
    loginPage.navigateToLoginPage();
    loginPage.checkLoginPageNavigation();
    System.out.println(registration.UserName);
    loginPage.LoginUser(registration.UserName, Password);
    homepage.searchCity(SearchCity);
    homepage.selectCity();

    Thread.sleep(3000);
    adventure.searchAdventure(AdventureName);
    Thread.sleep(3000);
    adventure.clickAdventure();
    Thread.sleep(5000);

    AdventureDetailsPage adventureDetails = new AdventureDetailsPage(driver);
    Thread.sleep(3000);
    adventureDetails.bookAdventure(GuestName, Date, count);
    Thread.sleep(3000);
    adventureDetails.verifyAdventureBooking();
    Thread.sleep(3000);
    adventureDetails.reservationClick();


    Thread.sleep(3000);
    history.storeTransactionId();
    Thread.sleep(3000);
    history.logout();
    Thread.sleep(3000);
  //  homePage.navigateToHomePage();
  }

  // @AfterClass(enabled = true)
  //   public void quitDriver() throws MalformedURLException {
  //       driver.close();
  //       // driver.quit();
  //       logStatus("driver", "Quitting driver", "Success");
  //   }
}

