package qtriptest.tests;

import qtriptest.DP;
import qtriptest.DriverSingleton;
import qtriptest.pages.*;
import qtriptest.pages.Registration;
import qtriptest.pages.HomePage;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.UUID;
import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
// import org.junit.BeforeClass;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.*;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class testCase_01 {

    static RemoteWebDriver driver;
    SoftAssert s_assert;

    Registration registrationPage;
    LoginPage loginPage;
    //public String UserName;

    // Method to help us Log our Unit Test
    public static void logStatus(String type, String message, String status) {

        System.out.println(String.format("%s | %s | %s | %s",
                String.valueOf(java.time.LocalDateTime.now()), type, message, status));
    }

    // Iinitialize webdriver for our Unit Tests
    @BeforeSuite(alwaysRun = true, enabled =true)
    // public static void createDriver() throws MalformedURLException {
    //     logStatus("driver", "Initializing driver", "Started");
    //     final DesiredCapabilities capabilities = new DesiredCapabilities();
    //     capabilities.setBrowserName(BrowserType.CHROME);
    //     driver = new RemoteWebDriver(new URL("http://localhost:8082/wd/hub"), capabilities);
    //     logStatus("driver", "Initializing driver", "Success");
    // }

    public static void createDriver() throws MalformedURLException {
        logStatus("driver", "Initializing driver", "Started");
        driver=DriverSingleton.getDriverInstance("chrome");
       // driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        logStatus("driver", "Initializing driver", "Success");
    }

    

    // @Test(description = "TO check user can register successfully", enabled = false)
    // //@Test(description = "verify the login flow of Qtrip user",dataProvider = "userOnboard",dataProviderClass = DP.class )
    // public void verifyRegisttrationFlow_test() throws InterruptedException {
    //     s_assert = new SoftAssert();
    //     registrationPage = new Registration(driver);
    //     System.out.println("From test==>" + registrationPage);
    //     registrationPage.navigateToRegisterPage();
    //     s_assert.assertTrue(
    //             registrationPage.registerNewUser("test169@email.com", "Test@1234", "Test@1234"),
    //             "Unable to register a new user in Qtrip");
    //    // s_assert.assertAll();
    // }

    //@Test(description = "verify the login flow of Qtrip user",dataProvider = "userOnboard",dataProviderClass = DP.class )
    @Test(dataProvider = "userOnboard",dataProviderClass = DP.class, enabled=true,description = "verify Login flow" , priority = 1, groups={"Login Flow"} )
    public void TestCase01(String UserName, String Password) throws InterruptedException {
       // this.UserName = UserName + UUID.randomUUID().toString();
        s_assert = new SoftAssert();
        loginPage = new LoginPage(driver);
        HomePage homepage = new HomePage(driver);
        Registration registration = new Registration(driver);

        homepage.navigateToHomePage();
        Thread.sleep(2000);
        homepage.navigateToRegisterPage();
        Thread.sleep(2000);
       // Registration.navigateToRegisterPage();
        //Registration.RegisterPageDispalyed();
        registration.registerNewUser(UserName, Password);
        Thread.sleep(2000);
        loginPage.navigateToLoginPage();
        loginPage.checkLoginPageNavigation();
        loginPage.LoginUser(registration.UserName, Password);
        loginPage.LogoutUser();

        //  try{
        //  loginPage.LoginUser(registration.UserName, Password);

        // }
        // catch(Exception e){
        //     Alert alert = driver.switchTo().alert();
        //     alert.accept();
           // System.out.println("No alert present at this moment.") ;
            
        }
    

  // @AfterClass(enabled = false)
    
//    @AfterClass(enabled = true)
//     public void quitDriver() throws MalformedURLException {
//         driver.close();
//         // driver.quit();
//         logStatus("driver", "Quitting driver", "Success");
//     }
}
