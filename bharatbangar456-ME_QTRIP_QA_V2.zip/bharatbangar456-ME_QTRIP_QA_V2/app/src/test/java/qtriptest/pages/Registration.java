package qtriptest.pages;

import java.util.UUID;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocator;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class Registration {
    RemoteWebDriver driver;
    String url = "https://qtripdynamic-qa-frontend.vercel.app/pages/register/";
    public String UserName;
    
    public Registration(RemoteWebDriver driver) {
        PageFactory.initElements(new AjaxElementLocatorFactory(driver,20),this);
        this.driver=driver ;
        //driver.manage().window().maximize();

        
    }

    // @FindBy(xpath = "//a[@class='nav-link login register']")
    // public static WebElement registerButton;
    
    @FindBy(name = "email")
    public static WebElement usernameText;

    @FindBy(name = "password")
    public static WebElement passwordText;

    @FindBy(name = "confirmpassword")
    public static WebElement confirmpasswordText;

    @FindBy(xpath = "//button[@type='submit']")
    public static  WebElement registerNowButton;

    // @FindBy(xpath = "//button[@type='submit']")
    // public WebElement LoginButton;


    

    //  public void navigateToRegisterPage(){
    //     if (!driver.getCurrentUrl().equals(this.url)) {
    //         driver.get(this.url);
    //         driver.manage().window().maximize();
    //     }
    //  }


    public boolean registerNewUser(String UserName, String password) throws InterruptedException {
       
        this.UserName = UserName + UUID.randomUUID().toString();
        // try {
        //     if (makeUserDynamic)
        //     {
        //         userName = userName + UUID.randomUUID().toString();
        //     }
        // System.out.println(this.UserName);
        usernameText.sendKeys(this.UserName);
        Thread.sleep(1000);
        
        passwordText.sendKeys(password);
        Thread.sleep(1000);
        
        confirmpasswordText.sendKeys(password);
        Thread.sleep(2000);
        
        registerNowButton.click();
       
        return true;
      // return driver.getCurrentUrl().split("/pages")[1].equals("/login");
         
       
        }
    }
    //     catch(Exception e)
    //     {
    //         e.printStackTrace();
    //     }
        
    // }
     // }


