package qtriptest.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class LoginPage {

    RemoteWebDriver driver;
    String url = "https://qtripdynamic-qa-frontend.vercel.app/pages/login/";

    public LoginPage(RemoteWebDriver driver){
        PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20), this);
        this.driver = driver;
        //driver.manage().window().maximize();
    }

    @FindBy (name = "email")
    public WebElement usernameText;
    
    @FindBy (name = "password")
    public WebElement passwordText;

    @FindBy (xpath = "//button[@type='submit']")
    public WebElement LoginButton;

    @FindBy (xpath = "//div[@onclick='Logout()']")
    public WebElement LogoutButton;

    private final static String LOGIN_PAGE_ENDPOINT = "/login/";

    

    public void navigateToLoginPage(){
        if (!driver.getCurrentUrl().equals(this.url)) {
            driver.get(this.url);
            driver.manage().window().maximize();
        }
      //  driver.get("https://qtripdynamic-qa-frontend.vercel.app/pages/login/");
    }
    
    public boolean checkLoginPageNavigation(){
        return driver.getCurrentUrl().contains(LOGIN_PAGE_ENDPOINT);
    }

    public boolean LoginUser(String userName, String password) throws InterruptedException {

        System.out.println (userName);
        usernameText.sendKeys(userName);
        passwordText.sendKeys(password);
        Thread.sleep(3000);
        LoginButton.click();
        Thread.sleep(3000);
        
        return driver.getCurrentUrl().equals("https://qtripdynamic-qa-frontend.vercel.app/");
    }

    public void LogoutUser() {
        LogoutButton.click();
    }
 

}
