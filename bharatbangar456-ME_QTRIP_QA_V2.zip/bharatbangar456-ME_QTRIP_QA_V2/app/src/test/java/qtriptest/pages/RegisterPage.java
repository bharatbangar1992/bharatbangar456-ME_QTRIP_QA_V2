package qtriptest.pages;


public class RegisterPage {
}
