// package qtriptest.pages;

// import org.openqa.selenium.remote.RemoteWebDriver;
// import org.openqa.selenium.By;
// import org.openqa.selenium.WebElement;
// import org.openqa.selenium.support.FindBy;
// import org.openqa.selenium.support.PageFactory;
// import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

// public class HomePage {

//  RemoteWebDriver driver;
//  String url = "https://qtripdynamic-qa-frontend.vercel.app/";


//     public HomePage(RemoteWebDriver driver) {
//         PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20), this);
//         this.driver = driver;
//     }

//     public void navigateToHomePage() throws InterruptedException{
//         driver.get("https://qtripdynamic-qa-frontend.vercel.app/");
//     }
// //      if(!driver.getCurrentUrl().equals(this.url)){
// //          driver.get(this.url);
// //          driver.manage().window().maximize();
// //    }
//  }
//     @FindBy( xpath ="//a[@class='nav-link login register']")
//     private WebElement registerLink;

//     @FindBy(xpath="//*[@id='autocomplete']")
//     WebElement search_valid_cityName;

//     @FindBy(xpath="//h5[text()='No City found']")
//     WebElement no_city_found;

//     @FindBy(xpath="//div/ul[@id='results']/a")
//     WebElement city_result;

//     public void navigateToRegisterPage() {
//         //registerLink.click();
//         driver.get("https://qtripdynamic-qa-frontend.vercel.app/pages/register/");
//     }

//     public void searchCity(String CityName) throws InterruptedException{

//         // search_valid_cityName.clear();
//         // Thread.sleep(3000);
//         search_valid_cityName.sendKeys(CityName);
//         Thread.sleep(3000);

//         if (city_result.isDisplayed())
//           { System.out.println("city is displayed on auto complete");
//           city_result.click();
            
//           }
//           else {
//             System.out.println("no matches found message is displayed");
//           }

//         }
//     // public boolean isCityNotFound(){
//     //     boolean status= false;
//     //     try{
//     //         status=no_city_found.isDisplayed();
//     //         return status;
//     //     }catch(Exception e){
//     //         return status;
//     //     }
//     // }
//     // public boolean isCityFound(){
//     //     boolean status= false;
//     //     try{
//     //         status=city_result.isDisplayed();
//     //         return status;
//     //     }catch(Exception e){
//     //         return status;
//     //     }
//     // }
    

    
// //     public void selectCity() throws InterruptedException{
// //         Thread.sleep(2000);
// //         city_result.click();
   
// // }
//     }


package qtriptest.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;


public class HomePage {

    RemoteWebDriver driver;
String url="https://qtripdynamic-qa-frontend.vercel.app";

@FindBy(id="autocomplete")
WebElement search_valid_cityName;

@FindBy(xpath="//h5[text()='No City found']")
WebElement no_city_found;

@FindBy(xpath="//div/ul[@id='results']/a")
WebElement city_result;

public HomePage(RemoteWebDriver driver){
    this.driver=driver;
    AjaxElementLocatorFactory ajax= new AjaxElementLocatorFactory(driver,  10);
    PageFactory.initElements(ajax, this);
}

public void navigateToHomePage() throws InterruptedException{

    if(!driver.getCurrentUrl().equals(url)){
        driver.get(url);
    }
}

public void navigateToRegisterPage() {
    //         //registerLink.click();
          driver.get("https://qtripdynamic-qa-frontend.vercel.app/pages/register/");
       }


public void searchCity(String CityName) throws InterruptedException{

    search_valid_cityName.clear();
    Thread.sleep(2000);
    search_valid_cityName.sendKeys(CityName);

}
public boolean isCityNotFound(){
    boolean status= false;
    try{
        status=no_city_found.isDisplayed();
        return status;
    }catch(Exception e){
        return status;
    }
}
public boolean isCityFound(){
    boolean status= false;
    try{
        status=city_result.isDisplayed();
        return status;
    }catch(Exception e){
        return status;
    }
}


public void selectCity() throws InterruptedException{
    Thread.sleep(3000);
    city_result.click();
//    WebDriverWait wait= new WebDriverWait(driver, 5);
//    wait.until(ExpectedConditions.urlToBe("https://qtripdynamic-qa-frontend.vercel.app"));
  }   

}
